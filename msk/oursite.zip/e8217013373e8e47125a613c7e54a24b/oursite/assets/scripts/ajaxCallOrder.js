$(document).on('click', 'form .main-project-content-form-bot__btn:not([unclickable])', function(e){
    e.preventDefault();

    errors = false;
    $('.main-project-content-form input[type=text]').each(function(e) {
        if($(this).val().length <= 0) {
            errors = true;
        }
    });
    if(errors) {
        //$('.main-project-content-form .answer').text('Заполните все поля.');
        console.log('Заполните все поля');
        return false;
    }
    dataInput = $('.main-project-content-form').serialize();
    $.ajax({
        type: 'POST',
        url: '../php/callBack.php',
        dataType: 'json',
        data: dataInput,
        success: function(response) {
            $('.main-project-content-form .answer').text(response.answer);
        }
    });
});

$(document).on('click', 'form .popup-form-bot__btn:not([unclickable])', function(e){
    e.preventDefault();

    errors = false;
    $('.popup-form input[type=text]').each(function(e) {
        if($(this).val().length <= 0) {
            errors = true;
        }
    });
    if(errors) {
        //$('.main-project-content-form .answer').text('Заполните все поля.');
        console.log('Заполните все поля');
        return false;
    }
    dataInput = $('.popup-form').serialize();
    $.ajax({
        type: 'POST',
        url: '../php/callBack.php',
        dataType: 'json',
        data: dataInput,
        success: function(response) {
            $('.popup-form .answer').text(response.answer);
        }
    });
});

$(document).on('click', 'form .vacancy-form-bot__btn:not([unclickable])', function(e){
    e.preventDefault();

    errors = false;
    $('.vacancy-form input[type=text]').each(function(e) {
        if($(this).val().length <= 0) {
            errors = true;
        }
    });
    if(errors) {
        //$('.main-project-content-form .answer').text('Заполните все поля.');
        console.log('Заполните все поля');
        return false;
    }
    dataInput = $('.vacancy-form').serialize();
    $.ajax({
        type: 'POST',
        url: '../php/callBack.php',
        dataType: 'json',
        data: dataInput,
        success: function(response) {
            $('.vacancy-form .answer').text(response.answer);
        }
    });
});