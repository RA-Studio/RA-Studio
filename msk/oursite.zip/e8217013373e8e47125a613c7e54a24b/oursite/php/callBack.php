<?php
require_once("phpMailer/PHPMailer.php");
require_once("phpMailer/Exception.php");
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if(!empty($_POST)){
    $siteName = $_SERVER['HTTP_REFERER'];
    foreach ($_REQUEST as $key => $value){
        $_REQUEST[$key] = htmlspecialchars($value, ENT_QUOTES);
    }

    $ok = 1;
    $mail_from = isset($_REQUEST['email']) ?  $_REQUEST['email'] : 'info@'.str_replace('/', '', str_replace('http://', '', $siteName));
    $mail = new PHPMailer();
    $mail->CharSet = "UTF-8";
    $mail->From = 'sales@clevergrad.ru';
    $mail->FromName = $siteName;

    $mail->addAddress('d.dyulger@ra-studio.ru');

    $mail->addReplyTo($mail->From, $mail->FromName);
    $mail->isHTML(true);
    $name = $_REQUEST['name'];
    $phone = $_REQUEST['tel'];

    $mail->Subject = $siteName;

    if (isset($_REQUEST['name'])){
        $mail->Body .= '<b>ФИО: </b>'.$_REQUEST['name'].'<br>';
    }
    if (isset($_REQUEST['email'])){
        $mail->Body .= '<b>E-mail: </b>'.$_REQUEST['email'].'<br>';
    }
    if (isset($_REQUEST['tel'])){
        $mail->Body .= '<b>Телефон: </b>'.$_REQUEST['tel'].'<br>';
    }
    if (isset($_REQUEST['education'])){
        $mail->Body .= '<b>Образование : </b>'.$_REQUEST['education'].'<br>';
    }
    if (isset($_REQUEST['experience'])){
        $mail->Body .= '<b>Опыт работы: </b>'.$_REQUEST['experience'].'<br>';
    }
    if (isset($_REQUEST['link'])){
        $mail->Body .= '<b>Ссылка на портфолио: </b>'.$_REQUEST['link'].'<br>';
    }
    if (isset($_REQUEST['description'])){
        $mail->Body .= '<b>Подробнее: </b>'.$_REQUEST['description'].'<br>';
    }
    if (isset($_FILES['file'])){
        $mail->Body .= '<b>Резюме (): </b>'.$_FILES['file'].'<br>';
    }

    $result = $_FILES['file'];
    if(!$mail->send()) {
        //$result = 'Mailer Error: ' . $mail->ErrorInfo;
        $rs = 'Mailer Error: ' . $mail->ErrorInfo;
    } else {
        $result = 'ok';
    }

    /*$name = htmlspecialchars($_POST['name']);
   $email = htmlspecialchars($_POST['email']);
   $phone = htmlspecialchars($_POST['tel']);
   $company = htmlspecialchars($_POST['company']);
   $description = htmlspecialchars($_POST['description']);

   /*$t= "<d.dyulger@ra-studio.ru>" ;
   $subject = "Заголовок письма";
   $message = ' <p>Текст письма</p> </br> <b>1-ая строчка </b> </br><i>2-ая строчка </i> </br>';
   $headers  = "Content-type: text/html; charset=utf-8 \r\n";
   $headers .= "From: От кого письмо <d.dyulger@ra-studio.ru>\r\n";
   $headers .= "Reply-To: d.dyulger@ra-studio.ru\r\n";

   $result = '';
   if (SendMail($to, $subject, $message, $headers)) {
       $result = 'Отправлено';
   }
   else {
       $result = 'Не отправлено';
   }*/

    echo json_encode(array(
        'response' => $result,
        'success' => true,
    ));
}
