<!doctype html>
<html lang=ru>
<head>
<meta charset=utf-8>
<meta http-equiv=X-UA-Compatible content="IE=edge">
<!--<meta name=">-->
<meta name=viewport content="width=device-width, initial-scale=1">
<title>Управление репутацией в интернете</title>
<meta name=mobile-web-app-capable content=yes>
<link rel=icon sizes=192x192 href=images/touch/chrome-touch-icon-192x192.png>
<meta name=apple-mobile-web-app-capable content=yes>
<link rel="shortcut icon" href="favicon.png" type="image/x-icon">
<meta name=apple-mobile-web-app-status-bar-style content=black>
<meta name=apple-mobile-web-app-title content="Web Starter Kit">
<link rel=apple-touch-icon-precomposed href=apple-touch-icon-precomposed.png>
<meta name=msapplication-TileImage content=images/touch/ms-touch-icon-144x144-precomposed.png>
<meta name=msapplication-TileColor content=#3372DF>
<link href="http://fonts.googleapis.com/css?family=Yeseva+One|Open+Sans:300italic,400,700&subset=cyrillic,latin" rel=stylesheet type=text/css>
<link rel=stylesheet href=styles/main.css>
<meta name="google-site-verification" content="deOEs1jiML9oitijAduZZ8M77UV1GJaldghW03LvzrI" />
<meta name="description" content="Агентство репутационного маркетинга RA-Studio: управление репутацией в интернете." />
<meta name="yandex-verification" content="69dd2083e5aee7cb" />
</head>
<body class=start-page>

<nav class=sidebar-nav id=sidebar-nav style="display: none;">
	<a href=#statistic class=sidebar-nav-link>Статистика</a> 
	<a href=#services class=sidebar-nav-link>Услуги</a>
	<a href=#audit class=sidebar-nav-link>Аудит</a> 
	<a href=#process class=sidebar-nav-link>Процесс работы</a> 
	<a href=#results class=sidebar-nav-link>Результаты</a>
	<a href=#contacts class=sidebar-nav-link>Контакты</a>
 </nav>

 <header class=header>
	<a href=index.php class=header-logo></a> 
	<button id=header-menu-toggle class=header-menu-toggle><span></span></button>
	<div class=header-right id=header-menu-wrapper>
	<nav class=header-nav>
		<a href=#home class="header-nav-link current"></a>
		<a href=#statistic class=header-nav-link>Статистика</a> 
		<a href=#services class=header-nav-link>Услуги</a> 
		<a href=#audit class=header-nav-link>Аудит</a> 
		<a href=#process class=header-nav-link>Процесс работы</a> 
		<a href=#results class=header-nav-link>Результаты</a> 
		<a href=#contacts class=header-nav-link>Контакты</a> 
		<a href=#map class=header-nav-link></a>
	</nav>
	
	<a href=tel:+7(812)611-2-333 class=header-phone>+7(812) 611-2-333</a>
	<a href="http://portfolio.ra-studio.ru/" target="_blanck" rel="noopener noreferrer" class=header-call-order >Портфолио</a>
	<a href=javascript:; class=header-call-order data-modal=modal-call-order>Заказать звонок</a>
	</div>
	</header>
	
	<nav class=pages-nav>
		<a href=#home class="pages-nav-link current"></a>
		<a href=#statistic class=pages-nav-link></a> 
		<a href=#services class=pages-nav-link></a> 
		<a href=#audit class=pages-nav-link></a> 
		<a href=#process class=pages-nav-link></a>
		<a href=#results class=pages-nav-link></a>
		<a href=#contacts class=pages-nav-link></a>
		<a href=#map class=pages-nav-link></a>
	</nav>
	<div class=pages-container>
	<section class="page bg-1" id=home>
			<article class=page-content>
			<div class=page-content-wrapper>
				<h1 class="page-content-title color-white">Вы уверены в репутации вашего бизнеса?</h1>
				<a href=javascript:; class=button data-modal=modal-audit-order>Получить консультацию</a>
			</div>
			</article>
	</section>
	
	<section class="page bg-2" id=statistic>
	<article class=page-content>
	<div class=page-content-wrapper>
	<img class=statistic-image src=images/content/img_people.png width=94 height=94>
	<blockquote class="quote color-white">
	<p class=quote-text>Если Вы не занимаетесь своей репутацией,<br>за вас это сделают другие</p>
	<p class=quote-author>&mdash; Генри Форд</p>
	</blockquote>
	<div class="statistic color-white">
	<div class=statistic-column>
	<p class=statistic-percent>
	<span class=odometer data-value=87>0</span>%</p><p class=statistic-text>пользователей <strong>безоговорочно верят</strong> данным, найденным в сети</p>
	</div>
	<div class=statistic-column>
		<p class=statistic-percent><span class=odometer data-value=81>0</span>%</p><p class=statistic-text>компаний <strong>теряют клиентов</strong> из-за негативных отзывов в интернете</p>
	</div>
	<div class=statistic-column>
		<p class=statistic-percent><span class=odometer data-value=34>0</span>%</p><p class=statistic-text>ваших конкурентов <strong>используют черный PR</strong> против вас</p>
	</div>
	<div class=statistic-column>
		<p class=statistic-percent><span class=odometer data-value=78>0</span>%</p><p class=statistic-text>организаций никак <strong>не контролируют</strong> брендовую поисковую выдачу</p>
	</div>
	</div>
	</div>
	<p class="statistic-footer color-white">*Данные получены на основе собственного исследования RA-Studio,<br>на базе анкетирования 2559 предпринимателей из 7 регионов России, в  ноябре 2017 года.</p>
	</article>
	</section>
	
	<section class=page id=services>
	<article class=page-content>
	<div class=page-content-wrapper>
	<h1 class=page-content-title>Мы готовы взять управление<br>репутацией вашей компании в свои руки</h1>
	<div class="service columns">
	<div class="columns-item col-3">
	<p class=columns-item-num>1</p>
	<h2 class=columns-item-title>Аналитика</h2>
	<p class=columns-item-text>Постоянный мониторинг и аналитика репутации, источников, выявление закономерностей между упоминаниями в сети, лояльностью аудитории и продажами</p>
	</div>
	<div class="columns-item col-3">
	<p class=columns-item-num>2</p>
	<h2 class=columns-item-title>Медиа</h2>
	<p class=columns-item-text>Создание и использование мощных каналов обратной связи с потребителем для реакции или раннего выявления возможных негативных последствий для репутации.</p>
	</div>
	<div class="columns-item col-3"><p class=columns-item-num>3</p>
	<h2 class=columns-item-title>Управление</h2><p class=columns-item-text>Выявление факторов, влияющих на репутацию компании, проведение работ по уменьшению негативного влияния на репутацию компании</p>
	</div>
	<div class=columns-item>
	<p class=columns-item-num>4</p>
	<h2 class=columns-item-title>SERM, Работа с негативом, Соцмедиа</h2>
	<p class=columns-item-text>Комплекс технических работ, нацеленных на достижение сбалансированной позитивной репутации, выяление негатива и его нейтрализация, увеличение активности компании и аудитории в социальных сетях, контроль и оптимизация поисковой выдачи по брендовым запросам.</p>
	</div>
	</div>
	</div>
	</article>
	</section>
	<section class="page bg-4" id=audit>
	<article class="page-content color-white">
	<div class=page-content-wrapper>
	<h3 class=page-content-heading>Уникальное предложение</h3>
	<h1 class=page-content-title>Конфиденциальный экспресс-аудит<br>репутации вашей компании - бесплатно!</h1>
<!--	<h2 class=page-content-subtitle>Стоимость услуги — бесплатно </h2>-->
	<hr class=divider><p class=page-content-text>Мы проводим аудит в условиях полной конфиденциальности ваших данных,<br>с заключением официального договора. Подробную информацию вы сможете получить<br>по телефону, сразу после оформления заявки. Срок выполнения аудита - 3 рабочих дня.</p>
	<p class=page-content-text>В результате вы получите понятную и прозрачную картину<br>реального состояния вашей репутации.</p>
	<br><a href=javascript:; class=button data-modal=modal-audit-order>Заказать аудит</a></div></article>
	</section><section class=page id=process><article class=page-content><div class=page-content-wrapper>
	<h1 class=page-content-title>Работа над репутацией компании<br>— непрерывный процесс</h1>
	<p class=page-content-text>Только комплексный аналитический подход может гарантировать уверенное улучшение репутации компании.<br>Аналитика — это основа правильной оценки и планирования.</p>
	</div>
	<div class=processes>
	<div class=processes-wrapper><div class=processes-item>
	<h2 class=processes-item-title>Аналитика</h2></div>
	<div class=processes-item><h2 class=processes-item-title>Планирование</h2></div>
	<div class=processes-item><h2 class=processes-item-title>Комплекс работ</h2></div>
	<div class=processes-item><h2 class=processes-item-title>Аудит</h2></div>
	<div class=processes-item><h2 class=processes-item-title>Корректировка</h2></div>
	</div>
	</div>
	<p class=processes-price>Фиксированная стоимость от <strong>15&nbsp;000&nbsp;руб/мес.</strong>*</p>
	<p class=page-content-text>*бюджет формируется на основе поставленных целей и результатов экспресс-аудита</p>
	</article>
	</section>
	<section class="page bg-6" id=results>
	<article class="page-content color-white">
	<div class=page-content-wrapper>
	<h3 class=page-content-heading>Результаты</h3>
	<h1 class=page-content-title>Уже после первого цикла работ<br>вы сможете оценить результаты</h1>
	<div class=columns>
	<div class="columns-item col-3">
	<h2 class=columns-item-title>Лояльность</h2>
	<p class=columns-item-text>Проведенные работы сглаживают влияние негатива, увеличивают лояльность аудитории и происходит формирование<br>имиджа надежной и клиенто-ориентированной компании</p>
	</div>
	<div class="columns-item col-3">
	<h2 class=columns-item-title>Узнаваемость</h2>
	<p class=columns-item-text>Увеличение количества упоминаний с положительной тональностью приводит к увеличению обсуждаемости<br>вашего бренда в масс медиа.</p>
	</div>
	<div class="columns-item col-3">
	<h2 class=columns-item-title>Безопасность</h2>
	<p class=columns-item-text>Формирование собственных<br>медиа-каналов бренда позволит предостеречь Вашу компанию<br>от негативного влияния<br>конкурентов на многие годы.</p>
	</div>
	</div>
	<br>
	<a href=javascript:; class=button data-modal=modal-audit-order>Заказать экспресс аудит</a>
	</div>
	</article>
	</section>
	<section class=page id=contacts>
	<article class=page-content>
	<div class=page-content-wrapper>
	<h1 class=page-content-title>Давайте обсудим ваш проект!</h1>
	<div class=contacts-container>
	<div class="contacts-column contacts-info">
	<h2 class=contacts-info-title></h2>
	<p class=contacts-info-item>
	<span class=contacts-info-item-label>Электронная почта:</span>
	<a href=mailto:info@ra-studio.ru class=contacts-info-item-value>info@ra-studio.ru</a>
	</p>
	<p class=contacts-info-item>
	<span class=contacts-info-item-label>Адрес офиса:</span> 
	<span class=contacts-info-item-value>Санкт-Петербург, БЦ "Кантемировский",</br> ул Инструментальная д 3, лит Х, офис 9</span>
	</p>
	<p class=contacts-info-item>
	<span class=contacts-info-item-label>Телефоны в Петербурге:</span> 
	<span class=contacts-info-item-value><a href="tel:78126112333">+7(812) 611-2-333</a>

	</span>
	</p>
	</div>
	<form class="contacts-column form contacts-form" id=contacts-form>
	<div class=form-control>
	<input class=form-input type=text name=name required>
	<label alt="Ваше имя" placeholder="Ваше имя">
	</label>
	</div>
	<div class=form-control>
	<input class=form-input type=text name=phone required> 
	<label alt="Телефон для связи*" placeholder="Телефон для связи*">
	</label>
	</div>
	<div class=form-control>
	<textarea class=form-textarea name=message required></textarea> 
	<label alt="Текст сообщения" placeholder="Текст сообщения"></label>
	</div>
	<input type=submit class="form-submit button-blue" value=Отправить>
	</form>
	</div>
	</div>
	</article>
	</section>
	<section class=page id=map>
	<div class=map-container id=YMapsID></div>
	<footer class=footer><div class=page-content-wrapper>
	<div class=footer-social>
	<a href=javascript:; class="social-icon facebook" title=Facebook>	</a> 
	<a href=javascript:; class="social-icon twitter" title=Twitter>	</a> 
	<a href=javascript:; class="social-icon vk" title=VK></a>
	<a title="Участник проекта CMS Magazine" href="http://www.cmsmagazine.ru/creators/ra-studio/?_type_jump=by_our_banner" target="_blank">
      <img style="vertical-align: baseline;" alt="Участник проекта CMS Magazine" title="Участник проекта CMS Magazine" src="http://www.cmsmagazine.ru/img/counters/gray_4.gif" border="0" />
    </a>
	</div>
	<p class=footer-text>(с) Ra-Studio 2013-<?php echo date('Y') ?>. Санкт-Петербург, БЦ "Кантемировский", ул Инструментальная д 3, лит Х, офис 9. Тел. +7(812) 611-2-333</p>
	</div>
	</footer>
	</section>
	</div>
	<div class=overlay id=overlay></div>
	<div class=modal id=modal-call-order>
	<a href=javascript:; class=modal-close></a><h2 class=modal-title>Заказать звонок</h2>
	<form class="form modal-form"><div class=form-control>
	<input class=form-input-large type=text name=name required> 
	<label alt="Ваше имя" placeholder="Ваше имя"></label></div>
	<div class=form-control><input class=form-input-large type=text name=phone required> 
	<label alt="Контактный телефон" placeholder="Контактный телефон"></label></div>
	<p class=form-footer>Мы не передаем ваши контактные данные третьим лицам</p>
	<input type=submit class=button-white value=Отправить></form>
	</div><div class=modal id=modal-audit-order>
	<a href=javascript:; class=modal-close></a>
	<h2 class=modal-title>Заказать экспресс-аудит</h2><form class="form modal-form">
	<div class=form-control><input class=form-input-large type=text name=name required> 
	<label alt="Ваше имя" placeholder="Ваше имя"></label></div>
	<div class=form-control><input class=form-input-large type=text name=phone required>
	<label alt="Контактный телефон" placeholder="Контактный телефон"></label>
	</div><p class=form-footer>Мы не передаем ваши контактные данные третьим лицам</p>
	<input type=submit class=button-white value=Отправить></form>
	</div>
	<script type=text/javascript src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script type=text/javascript src="https://maps.googleapis.com/maps/api/js?key=AIzaSyACDOKxDgqSSbz_Vb0pmauGuHp7OEDc4Bw&sensor=false"></script>
	<script type="text/javascript" src="https://api-maps.yandex.ru/2.1/?lang=ru_RU"></script>
	<script src=scripts/main.min.js></script>

	​<script type="text/javascript">(window.Image ? (new Image()) : document.createElement('img')).src = location.protocol + '//vk.com/rtrg?r=YQXkWwUPr*iQoyr2O35xwh5nznxRThaNhxrNoxdhSOfhQz/TurT5R2Ki0Q3HXzX75k9/8YWIMP*BgNQ18OwuqT6HXCnemKHZzjs*eYMCipE8UGmi*RPfOZelTuk2JpU3De4HkdTs1udhCcbdJulrjtPZqrR/Djnrp8kWJMuEx*0-';</script>​


<!-- Google Tag Manager -->
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-5RHZC2"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5RHZC2');</script>
<!-- End Google Tag Manager -->	
	
	


</body></html>