<?php

$phone = isset($_REQUEST['phone']) ? trim($_REQUEST['phone']) : '';
$name = isset($_REQUEST['name']) ? trim($_REQUEST['name']) : '';
$message = isset($_REQUEST['message']) ? trim($_REQUEST['message']) : '';

$result = array('error' => true);

try {
	//$db = new PDO('mysql:dbname=p218526_db;host=p218526.mysql.ihc.ru', 'p218526_db', '696CG86Mv2');

	if ($phone && $name && $message) {
		//$ip = ip2long($_SERVER['REMOTE_ADDR']);
		
		//$sth = $db->query('SELECT COUNT(ip) as `total` FROM `logs` WHERE ip = ' . $ip . ' AND `date` > DATE_SUB(NOW(), interval 3 minute)');
		//$data = $sth->fetch(PDO::FETCH_ASSOC);

		//if ($data['total'] >= 5) {
		//	$result['errorCode'] = 1;
		//} else {
			//$db->exec('INSERT INTO `logs` VALUES (' . $ip . ', NOW())');
			$subject = "Сообщение с сайта Ra-Studio";
			$msg = "Имя: " . $name .  "\r\n" . "Телефон: " . $phone . "\r\n\r\n" . $message;
			if (mail('rnet2005@gmail.com, an.shalnova@yandex.ru, ak@ra-studio.ru', $subject, $msg)) {
				$result = array('success' => true);
                                echo "<script>alert('Заявка успешно отправлена. Мы свяжемся с вами в течение 15-ти минут.');</script>";
			}
		//}
	} else {
		$result['errorCode'] = 2;
	}

} catch (Exception $e) {
	$result['errorCode'] = 3;
}

echo json_encode($result);